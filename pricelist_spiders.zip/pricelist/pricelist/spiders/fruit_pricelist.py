# -*- coding: utf-8 -*-
import scrapy
import logging

class VegPricelistSpider(scrapy.Spider):
    handle_httpstatus_list=[401,404]
    name = 'fruit_pricelist'
    allowed_domains = ['market.todaypricerates.com']
    start_urls = ['https://market.todaypricerates.com/fruits-daily-price']

    def parse(self, response):

        states = response.xpath("//td/a")
        for state in states:
            name = state.xpath(".//text()").get()
            link = state.xpath(".//@href").get()
            yield response.follow(url=link, callback=self.parse_state, meta={'state_name': name})
    
    def parse_state(self, response):
        name = response.request.meta['state_name']
        #rows = response.xpath("(//table[@class='table table-striped table-bordered table-hover table-condensed table-list'])[1]/tbody/tr")
        #rows = response.xpath("(//div[@class='Table'])/div[@class='Row']/div")
        #rows = response.xpath("(//div[@class='Table'])/div[@class='Row']/div/").getall()
        rows = response.xpath("(//div[@class='Table'])/div[@class='Row']")
        for row in rows:
            fruit = row.xpath(".//div[1]/text()").get()
            unit = row.xpath(".//div[2]/text()").get()
            market_price = row.xpath(".//div[3]/text()").get()
            retail_price = row.xpath(".//div[4]/text()").get()
            mall = row.xpath(".//div[5]/text()").get()
            
            yield {
                'state name': name,
                'fruit name': fruit,
                'units': unit,
                'market price':market_price,
                'retail price':retail_price,
                'mall price':mall 
            }
